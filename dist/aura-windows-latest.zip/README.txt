﻿AURA Windows latest build

Commit: d3d20965
Built: 2026-05-13 23:59:20 +09:00

Files:
- aura-gui.exe
- aura-safety-gateway.exe

Run GUI:
.\\aura-gui.exe

Run Safety Gateway:
.\\aura-safety-gateway.exe --serve --ui --listen-host 127.0.0.1 --listen-port 8765
